# init basic functions

__author__ = """Niu Du"""
__email__ = 'jiyin.dna@gmail.com'
__version__ = '1.0.0'

from .cite_count import AB_count,RNA_count,CITE_count
