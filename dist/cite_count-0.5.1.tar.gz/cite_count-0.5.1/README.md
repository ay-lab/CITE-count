CITE-count
============


Preprocess fastq files and filter out low Antibody count 
----------------------
* Input unziped fastq filrs (forward and reverse).
  to be finished

Import RNA data from Seurat, scanpy and count table
----------------------


Allow clustering of single cells using CITE seq data in a flowcytometry fashion
----------------------
* Aliquot sc data
